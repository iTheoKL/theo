(() => {
  const serpent = document.querySelector('.vapor-serpent');
  if (!serpent) return;
  serpent.addEventListener('pointermove', event => {
    const bounds = serpent.getBoundingClientRect();
    serpent.style.setProperty('--serpent-x', `${((event.clientX - bounds.left) / bounds.width - .5) * 16}px`);
    serpent.style.setProperty('--serpent-y', `${((event.clientY - bounds.top) / bounds.height - .5) * 10}px`);
  }, { passive: true });
  serpent.addEventListener('pointerleave', () => {
    serpent.style.setProperty('--serpent-x', '0px');
    serpent.style.setProperty('--serpent-y', '0px');
  });
})();
