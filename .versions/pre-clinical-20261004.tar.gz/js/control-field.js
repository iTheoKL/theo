(() => {
  const canvas = document.getElementById('control-field');
  if (!canvas) return;
  const ctx = canvas.getContext('2d');
  if (!ctx) return;
  let width=0,height=0,frame=0,visible=false,last=0;
  const target={x:-1,y:-1},point={x:-1,y:-1};
  function resize(){const rect=canvas.getBoundingClientRect();width=rect.width;height=rect.height;const dpr=Math.min(devicePixelRatio,1.5);canvas.width=width*dpr;canvas.height=height*dpr;ctx.setTransform(dpr,0,0,dpr,0,0);}
  new ResizeObserver(resize).observe(canvas);
  canvas.addEventListener('pointermove',event=>{const rect=canvas.getBoundingClientRect();target.x=event.clientX-rect.left;target.y=event.clientY-rect.top;});
  canvas.addEventListener('pointerleave',()=>{target.x=-1;target.y=-1;});
  canvas.addEventListener('focus',()=>{target.x=width/2;target.y=height/2;});
  canvas.addEventListener('blur',()=>{target.x=-1;target.y=-1;});
  canvas.addEventListener('keydown',event=>{const keys={ArrowLeft:[-25,0],ArrowRight:[25,0],ArrowUp:[0,-25],ArrowDown:[0,25]};if(!keys[event.key])return;event.preventDefault();target.x=Math.max(0,Math.min(width,target.x+keys[event.key][0]));target.y=Math.max(0,Math.min(height,target.y+keys[event.key][1]));});
  function draw(now){if(!visible||document.hidden){frame=0;return;}frame=requestAnimationFrame(draw);if(now-last<33)return;last=now;const t=now*.00015;
    point.x+=(target.x-point.x)*.035;point.y+=(target.y-point.y)*.035;
    ctx.clearRect(0,0,width,height);ctx.fillStyle='#070d0a';ctx.fillRect(0,0,width,height);
    ctx.globalCompositeOperation='screen';
    for(let i=0;i<42;i++){
      const k=i/42;const x=width*(.5+.46*Math.sin(k*7.4+t*.65));const y=height*(.5+.37*Math.cos(k*9.2-t));
      const radius=height*(.13+.10*Math.sin(i*2.3+t)**2);const g=ctx.createRadialGradient(x,y,0,x,y,radius);
      g.addColorStop(0,'rgba(109,139,59,.18)');g.addColorStop(.45,'rgba(47,95,59,.11)');g.addColorStop(1,'rgba(10,25,12,0)');ctx.fillStyle=g;ctx.fillRect(x-radius,y-radius,radius*2,radius*2);
    }
    ctx.globalCompositeOperation='source-over';
    if(point.x>0){const g=ctx.createRadialGradient(point.x,point.y,5,point.x,point.y,105);g.addColorStop(0,'rgba(3,8,5,.96)');g.addColorStop(.55,'rgba(3,8,5,.7)');g.addColorStop(1,'rgba(3,8,5,0)');ctx.fillStyle=g;ctx.fillRect(0,0,width,height);}
  }
  const observer=new IntersectionObserver(entries=>{visible=entries[0].isIntersecting;if(visible&&!frame)frame=requestAnimationFrame(draw);},{threshold:.05});observer.observe(canvas);
  document.addEventListener('visibilitychange',()=>{if(!document.hidden&&visible&&!frame)frame=requestAnimationFrame(draw);});
})();
